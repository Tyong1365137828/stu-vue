### 一. Promise

#### 1.1. Promise的基本使用

* 如何将异步操作放入到promise中
* (resolve, reject) => then/catch



#### 1.2. Promise的链式调用



#### 1.3. Promise的all方法





### 二. Vuex

#### 2.1. 什么是状态管理



#### 2.2. Vuex的基本使用

* state -> 直接修改state(错误)
* mutations -> devtools



#### 2.3. 核心概念

* state -> 单一状态树
* getters -> 
* mutations -> 
* actions -> 异步操作(Promise)
* modules



#### 2.4. 目录组织方式





### 三. 网络请求封装

#### 3.1. 网络请求方式的选择



#### 3.2. axios的基本使用



#### 3.3. axios的相关配置



#### 3.4. axios的创建实例



#### 3.5. axios的封装



#### 3.6. axios的拦截器





### 四. 项目开发

#### 4.1. 划分目录结构



#### 4.2. 引用了两个css文件



#### 4.3. vue.config.js和.editorconfig



#### 4.4. 项目的模块划分: tabbar -> 路由映射关系



#### 4.5. 首页开发

* navbar 的封装
* 网络数据的请求
* 轮播图
* 推荐信息



```
git remote add origin https://github.com/coderwhy/testmall.git
git push -u origin master
```















sync -> 同步

async -> 异步



aysnc operation: 操作



xcode/iphonex/xml

token -> 



linus -> linux/git

